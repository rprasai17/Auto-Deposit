module.exports = {
    output: {
        libraryTarget: 'window',
        library: 'App'
    },
    optimization: {
        minimize: false
    }
}